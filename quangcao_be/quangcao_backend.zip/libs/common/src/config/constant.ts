export const IS_PUBLIC_KEY = 'isPublic';
export const IS_PERMISSION_KEY = 'isPermission';

export const EventEmitterKey = {
	COMMENT_CREATE: 'comment.create',
};
