// Đã chuyển sang dùng DocumentBase cho Mongoose, file này có thể bỏ hoặc để trống nếu không còn dùng.
