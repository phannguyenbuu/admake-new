import { faker } from '@faker-js/faker/locale/vi';
import '@libs/common/extensions/index';

export const ACCESS_TOKEN =
	'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI2ODc2NmZmMzU4MjMxZTQzNDNjYjJjMjEiLCJ1c2VybmFtZSI6InR1YW5uYyIsInN0YXR1cyI6ImFjdGl2ZSIsImhhc2hLZXkiOiJlZjU5ZjViZmQ5MmYwNWRlNGQzZjRhMDZlZjhmM2EwMiIsImlhdCI6MTc1MzE1NDgyOCwiZXhwIjoxNzg0NzEyNDI4fQ.T0zpO1SzLAUMHDFZmszbqmQ38q5dTcJ4r-OJmhw-6Z0';

export const fakerJs = faker;
