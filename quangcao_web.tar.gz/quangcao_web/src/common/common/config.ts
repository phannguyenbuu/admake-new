export const TOKEN_LABEL = 'admake-secret-token';
