export enum UserStatus {
  ACTIVE = "ACTIVE",
  INACTIVE = "INACTIVE",
}
export enum UserPartialStatus {
  ACTIVE = "Đang thi công",
  INACTIVE = "Nghỉ phép",
}
