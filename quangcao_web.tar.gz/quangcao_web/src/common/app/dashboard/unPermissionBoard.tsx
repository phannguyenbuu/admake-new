import { Typography } from "antd";

export default function UnPermissionBoard() {
    return <Typography>Bạn không được cấp quyền để xem mục này</Typography>
}