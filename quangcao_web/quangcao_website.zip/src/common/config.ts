export const TOKEN_LABEL = 'ACCESS_TOKEN';
