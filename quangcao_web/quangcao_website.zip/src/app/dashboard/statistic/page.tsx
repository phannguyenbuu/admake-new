import type { IPage } from "../../../@types/common.type";

export const StatisticDashboard: IPage["Component"] = () => {
  return <div>StatisticDashboard</div>;
};
